## 1.1.1 (2017-04-28)

Changes:
	- Update to README.md and packaging

## 1.1.0 (2017-04-28)

Features:
	- Include td and th
	- Update dev dependencies and CONTRIBUTING.md
	- Cleanup repo tags/releases
